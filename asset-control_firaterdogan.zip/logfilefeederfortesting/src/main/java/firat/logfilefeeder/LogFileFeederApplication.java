package firat.logfilefeeder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication
public class LogFileFeederApplication implements CommandLineRunner {

    @Autowired
    private LogFileFeeder logFileFeeder;

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(LogFileFeederApplication.class);
        app.run(args);

    }

    @Bean
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(10);
        executor.setWaitForTasksToCompleteOnShutdown(false);
        return executor;
    }

    @Override
    public void run(String... args) throws Exception {
        this.logFileFeeder.start();
    }
}
