package firat.logfilefeeder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class LogFileFeeder {

    @Autowired
    private ApplicationContext context;


    @Value("${maxWait:1000}")
    private int maxWaitInMillisecondForNewLogLine;

    @Value("${logFile:}")
    private String logFile;

    @Value("${numberOfThread:10}")
    private int numberOfThread;

    @Autowired
    private ThreadPoolTaskExecutor taskExecutor;

    public void start() {

        if (StringUtils.isEmpty(this.logFile)) {
            System.err.println("Log file path cannot be empty");
            return;
        }

        for (int i = 0; i < this.numberOfThread; i++) {
            LogFileFeederTask logFileFeederTask = this.context.getBean(LogFileFeederTask.class);
            logFileFeederTask.setLogFile(this.logFile);
            logFileFeederTask.setMaxWait(this.maxWaitInMillisecondForNewLogLine);
            logFileFeederTask.setThreadName("Thread" + (i + 1));
            this.taskExecutor.execute(logFileFeederTask);

        }
    }

}
