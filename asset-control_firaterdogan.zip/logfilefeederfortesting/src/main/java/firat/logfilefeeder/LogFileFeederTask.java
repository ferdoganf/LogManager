package firat.logfilefeeder;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

@Component
@Scope("prototype")
public class LogFileFeederTask implements Runnable {

    private String threadName;
    private int maxWait;
    private String logFile;

    public void setThreadName(String threadName) {
        this.threadName = threadName;
    }

    public void setMaxWait(int maxWait) {
        this.maxWait = maxWait;
    }

    public void setLogFile(String logFile) {
        this.logFile = logFile;
    }

    @Override
    public void run() {
        System.out.println("Thread " + this.threadName + " running..");
        Random random = new Random();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss,SSS");
        try (FileWriter writer = new FileWriter(this.logFile, true)) {
            int k = 0;
            while (k < Integer.MAX_VALUE) {
                k++;

                StringBuilder stringBuilder = new StringBuilder();
                LocalDateTime now = LocalDateTime.now();
                String formatDateTime = now.format(formatter);

                stringBuilder.append(formatDateTime);
                int errorType = random.nextInt(3);
                if (errorType == 0) {
                    stringBuilder.append(" ERROR ");
                } else if (errorType == 1) {
                    stringBuilder.append(" WARNING ");
                } else {
                    stringBuilder.append(" INFO ");
                }

                int errorLength = random.nextInt(100) + 1;
                stringBuilder.append(RandomStringUtils.randomAlphabetic(errorLength));

                writer.write(stringBuilder.toString());
                writer.write(System.getProperty("line.separator"));
                writer.flush();

                int wait = random.nextInt(this.maxWait) + 1;
                Thread.sleep(wait);
            }
        } catch (Exception ex) {
            System.err.println("Thread " + this.threadName + " file write error.");
            System.err.println(ex);
        }
    }
}