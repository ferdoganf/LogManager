# LogMonitor

LogMonitor reads the log file, stores logs in a inmemory data structure and transfers to html client via websocket.

 # Logical Modules
 
 1. **File Reader**: Reads file and stores the log item in a data structures. After initial load, an async worker loads new log lines from file and stores them.
  
 2. **Web Socket Handler**: Manages the socket connections and data transfer from in memory data structures to client via web scoket
 
 3. **MVC Controller+ Html Client**: Controller, HTML 5 client, web socket client and css/js files.
 
 4. **Configuration**: Spring Boot config, a configuration yml file, Applications Properties (property holder)
 
 # Configuration (application.yml)
 
**server.port**: Http Port    
    `default: 8081`
  
**logging.firat.logmonitor**: Log Level   
    `default_: DEBUG`
  
**logFile**: Log file path that will be read    
`default: "D:\\dev\\bitbucket\\test\\app.log"`
 
**logFileDateTimeZone**: Time Zone of date strings in the log file     
`default: "Asia/Baghdad"`
 
**logItemsInMemoryMaxLimit**: Maximum number of log item can be in memory. if the number of log items exceed this number, FIFO evict will be applied.   
`default:10000000`
 
**defaultMonitoringInterval**:  default monitoring interval for clients     
`default:2`
 
**logFileTailDelayMillis**: wait when new log line does not exist   
`default:200`
 
**logFileDateFormat**: Format of date strings in the log file
`default:"yyyy-MM-dd HH:mm:ss,SSS"`
 