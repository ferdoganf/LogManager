package firat.logmonitor.repository;

import firat.logmonitor.model.LogItem;

import java.time.Instant;
import java.util.Collection;

/**
 * @author  Firat Erdogan
 * @version 1.0
 */
public interface LogItemRepository {
    void addLogItem(LogItem logItem);
    Collection<LogItem> getLogItems(Instant reportStartTime);
}