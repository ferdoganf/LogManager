package firat.logmonitor.repository;

import firat.logmonitor.config.ApplicationProperties;
import firat.logmonitor.model.LogItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentSkipListSet;

/**
 * This class holds the log item map and
 * provides put/get/delete functions for the map
 * LogItems are hold in ConcurrentHashMap so methods are thread-safe.
 * The maximum number of logItem in the map is limited by logItemsInMemoryMaxLimit properties
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Component
public class LogItemRepositoryImpl implements LogItemRepository{

    private static final Logger log = LoggerFactory.getLogger(LogItemRepository.class);

    @Autowired
    private ApplicationProperties applicationProperties;

    /***
    ****
    ****
    private SortedMultiset<LogItem> logItems = TreeMultiset.create();
    public synchronized void addToLogItemSet(LogItem logItem) {
        if(logItems.size() >= logItemsInMemoryMaxLimit) {
            logItems.pollFirstEntry();
        }
        this.logItems.add(logItem);
    }
    ****
    ****
    ****/

    private NavigableSet<LogItem> logItems = new ConcurrentSkipListSet<>();

    /**
     * This method used to add/replace log item.
     * Remove oldest log item when list size equals the limit
     * @param logItem log item.
     * @see LogItem
     */
    @Override
    public void addLogItem(LogItem logItem) {
        if(logItems.size() >= applicationProperties.getLogItemsInMemoryMaxLimit()) {
            logItems.pollFirst();
        }
        this.logItems.add(logItem);
        log.debug("Log Item added : " + logItem);
    }

    /**
     * Returns log items in the interval of time
     * @return collection of log items
     * @see LogItem
     */
    @Override
    public Collection<LogItem> getLogItems(Instant reportStartTime) {
        log.debug("Log Items is fetching..");
        return this.logItems.tailSet(new LogItem(reportStartTime));
    }
}
