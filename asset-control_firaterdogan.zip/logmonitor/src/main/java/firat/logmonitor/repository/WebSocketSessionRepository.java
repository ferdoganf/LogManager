package firat.logmonitor.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/**
 * @author  Firat Erdogan
 * @version 1.0
 */
public interface WebSocketSessionRepository {

    void putWebSocketSession(WebSocketSession webSocketSession);
    void removeWebSocketSession(String sessionId);
    void removeWebSocketSession(WebSocketSession session);
    Collection<WebSocketSession> getWebSocketSessions();

}