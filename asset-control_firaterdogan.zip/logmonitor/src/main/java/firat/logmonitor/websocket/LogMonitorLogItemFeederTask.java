package firat.logmonitor.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import firat.logmonitor.model.LogItem;
import firat.logmonitor.repository.LogItemRepository;
import firat.logmonitor.repository.WebSocketSessionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.time.Instant;
import java.util.Collection;

/**
 * This class collect the log items after last push
 * Then push to clients
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Component
@Scope("prototype")
public class LogMonitorLogItemFeederTask implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(LogMonitorLogItemFeederTask.class);

    @Autowired
    private WebSocketSessionRepository webSocketSessionHolder;

    @Autowired
    private LogItemRepository logItemRepository;

    private ObjectMapper mapper = new ObjectMapper();

    /**
     * collects and pushes log items to clients
     *
     *
     * @author  Firat Erdogan
     * @version 1.0
     */
    @Override
    public void run() {
        System.out.println("LogMonitorLogItemFeederTask running..");

        int k = 0;
        Instant reportTime = Instant.now().minusSeconds(5);
        long reportTimeMilli = reportTime.toEpochMilli();
        while (k < Integer.MAX_VALUE) {
            try {
                Collection<WebSocketSession> webSocketSessions = this.webSocketSessionHolder.getWebSocketSessions();
                Collection<LogItem> logItems = logItemRepository.getLogItems(Instant.ofEpochMilli(reportTimeMilli));
                ObjectNode messageNode = mapper.createObjectNode();
                ArrayNode logItemsNode = mapper.createArrayNode();
                for (LogItem logitem : logItems) {
                    ObjectNode logItemNode = mapper.createObjectNode();
                    logItemNode.put("UUID", logitem.hashCode());
                    logItemNode.put("TIME", logitem.getLogTimeInMillis());
                    logItemNode.put("TYPE", logitem.getLogType());
                    logItemsNode.add(logItemNode);
                    if(logitem.getLogTimeInMillis() > reportTimeMilli) {
                        reportTimeMilli = logitem.getLogTimeInMillis();
                    }
                }
                messageNode.put("reportDate", Instant.now().toEpochMilli());
                messageNode.set("logItems", logItemsNode);

                try {
                    for (WebSocketSession webSocketSession : webSocketSessions) {
                        webSocketSession.sendMessage(new TextMessage(messageNode.toString()));
                    }
                } catch (Exception e) {
                    log.error("webSocketSession.sendMessage exception", e);
                }
                Thread.sleep(1000);
            } catch (Exception e) {
                log.error("LogMonitorLogItemFeederTask exception", e);
            }
        }
    }
}
