package firat.logmonitor.websocket;

import firat.logmonitor.config.ApplicationProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

/**
 * This class starts async websocket logitem feed feed
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Component
public class LogMonitorLogItemFeeder implements InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(LogMonitorLogItemFeeder.class);

    @Autowired
    private ApplicationContext context;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private ThreadPoolTaskExecutor taskExecutor;

    /**
     * start LogMonitorLogItemFeederTask thread
     * @see LogMonitorLogItemFeederTask
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        LogMonitorLogItemFeederTask logMonitorLogItemFeederTask = this.context.getBean(LogMonitorLogItemFeederTask.class);
        this.taskExecutor.execute(logMonitorLogItemFeederTask);
    }

}
