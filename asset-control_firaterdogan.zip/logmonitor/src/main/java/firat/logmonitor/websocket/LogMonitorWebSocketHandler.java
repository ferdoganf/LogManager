package firat.logmonitor.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import firat.logmonitor.config.ApplicationProperties;
import firat.logmonitor.model.LogItem;
import firat.logmonitor.repository.LogItemRepository;
import firat.logmonitor.repository.WebSocketSessionRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.IOException;
import java.time.Instant;
import java.util.Collection;
import java.util.List;

/**
 * Web socket connection handler class
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Component
public class LogMonitorWebSocketHandler extends TextWebSocketHandler {

    private static final Logger log = LoggerFactory.getLogger(WebSocketSessionRepository.class);

    @Autowired
    private WebSocketSessionRepository webSocketSessionHolder;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private LogItemRepository logItemRepository;

    /**
     * remove websocket session
     *
     * @param session websocket session
     * @param status websocket status
     *
     */
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        try {
            if (!status.equals(CloseStatus.NORMAL)) {
                session.close();
            }
        } catch (IOException e) {
            log.error("Cannot close session on afterConnectionClosed", e);
        }
        this.webSocketSessionHolder.removeWebSocketSession(session);
    }

    /**
     * load and push initial log items
     *
     * @param session websocket session
     * @param monitoringInterval monitoring interval
     *
     */
    private void loadInitialLogItemsForWebSocketSession(WebSocketSession session, int monitoringInterval) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        Instant reportTime = Instant.now();
        Collection<LogItem> logItems = logItemRepository.getLogItems(reportTime.minusSeconds(monitoringInterval+1));
        ObjectNode messageNode = mapper.createObjectNode();
        ArrayNode logItemsNode = mapper.createArrayNode();
        for (LogItem logitem:logItems) {
            ObjectNode logItemNode = mapper.createObjectNode();
            logItemNode.put("UUID",logitem.hashCode());
            logItemNode.put("TIME",logitem.getLogTimeInMillis());
            logItemNode.put("TYPE",logitem.getLogType());
            logItemsNode.add(logItemNode);
        }
        messageNode.put("reportDate",reportTime.toEpochMilli());
        messageNode.set("logItems",logItemsNode);
        session.sendMessage(new TextMessage(messageNode.toString()));
    }

    /**
     * starts init messages
     *
     * @param session websocket session
     *
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {

        List<String> cookies = session.getHandshakeHeaders().get("COOKIE");
        int monitoringInterval = Integer.parseInt(this.applicationProperties.getDefaultMonitoringInterval());
        for (String cookie : cookies) {
            String cookiePart[] = StringUtils.split(cookie,";");
            if((cookiePart != null) && (cookiePart.length > 0)) {
                for (String cookieOnePart : cookiePart) {
                    String[] cookieNameValue = StringUtils.split(cookieOnePart,"=");
                    if(cookieNameValue != null && (cookieNameValue.length == 2)) {
                        if(StringUtils.trim(cookieNameValue[0]).equalsIgnoreCase(ApplicationProperties.COOKIE_NAME_MONITORING_INTERVAL)) {
                            monitoringInterval = Integer.parseInt(StringUtils.trim(cookieNameValue[1]));
                            break;
                        }
                    }
                }
            }
        }

        log.debug("afterConnectionEstablishedfor the session: ", session);
        this.webSocketSessionHolder.putWebSocketSession(session);
        loadInitialLogItemsForWebSocketSession(session, monitoringInterval);
    }

    /**
     * monitoring interval of session changed, starts initial load
     *
     * @param session websocket session
     * @param textMessage message
     *
     */
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage textMessage) throws Exception {
        loadInitialLogItemsForWebSocketSession(session,  Integer.parseInt(textMessage.getPayload()));
    }

    /**
     * remove websocket session
     *
     * @param session websocket session
     * @param exception exception
     *
     */
    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        log.debug("error has occured for the session: ", session);
        try {
            session.close();
        } catch (IOException e) {
            log.error("Cannot close session on handleTransportError ", e);
        }
        this.webSocketSessionHolder.removeWebSocketSession(session);
    }
}