package firat.logmonitor.logfile;

import firat.logmonitor.config.ApplicationProperties;
import firat.logmonitor.model.LogItem;
import firat.logmonitor.repository.LogItemRepository;
import org.apache.commons.io.input.Tailer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.stream.Stream;

/**
 * Class for initial read log file and then subscribe for tail
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Component
public class LogFileReader implements InitializingBean, DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(LogFileReader.class);

    private Tailer tailer;

    @Autowired
    private LogFileTailerListener logFileTailerListener;

    @Autowired
    private LogItemRepository logItemRepository;

    @Autowired
    private ApplicationProperties applicationProperties;

    /**
     * Reads whole log file and store log items in repository
     * Than opens a new Thread for tailing the log file
     * @see LogFileTailerListener
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (StringUtils.isEmpty(this.applicationProperties.getLogFile())) {
            log.error("Log file path cannot be empty");
            throw new Exception("Log file path cannot be empty");
        }

        log.debug("old logs loading..");
        Instant startTime = Instant.now();
        try (Stream<String> stream = Files.lines(Paths.get(this.applicationProperties.getLogFile()))) {
            stream.forEach((line)->{
                LogItem logItem = new LogItem(line,applicationProperties.getLogFileDateTimeZone(), applicationProperties.getFormatter());
                this.logItemRepository.addLogItem(logItem);
                log.debug("new logItem added.");

            });
        } catch (IOException e) {
            log.error("Read file exception", e);
        }
        Instant endTime = Instant.now();
        log.debug("old logs loaded in "+ Duration.between(startTime,endTime).toMillis()+" ms");

        log.debug("tail starting..");
        this.tailer = new Tailer(new File(this.applicationProperties.getLogFile()), logFileTailerListener, this.applicationProperties.getLogFileTailDelayMillis(), true);
        Thread thread = new Thread(tailer);
        thread.start();
    }

    /**
     * Stops tailer
     * @see LogFileTailerListener
     */
    @Override
    public void destroy() throws Exception {
        tailer.stop();
    }
}
