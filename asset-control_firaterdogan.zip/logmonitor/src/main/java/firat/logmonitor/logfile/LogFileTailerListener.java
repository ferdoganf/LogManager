package firat.logmonitor.logfile;

import firat.logmonitor.config.ApplicationProperties;
import firat.logmonitor.model.LogItem;
import firat.logmonitor.repository.LogItemRepository;
import org.apache.commons.io.input.TailerListenerAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

/**
 * TailerListenerAdapter for tail log file
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Component
public class LogFileTailerListener extends TailerListenerAdapter{

    private static final Logger log = LoggerFactory.getLogger(LogFileTailerListener.class);

    @Autowired
    private LogItemRepository logItemRepository;

    @Autowired
    private ApplicationProperties applicationProperties;

    /**
     * This method trguggered when a new log line is writen
     * Method creates new LogItem object and store in logItem repository
     * @param s log line String
     * @see LogItemRepository
     */
    @Override
    public void handle(String s) {
        LogItem logItem = new LogItem(s,applicationProperties.getLogFileDateTimeZone(), applicationProperties.getFormatter());
        this.logItemRepository.addLogItem(logItem);
        log.debug("new logItem added.");
    }
}
