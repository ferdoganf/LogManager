package firat.logmonitor.model;

import org.apache.commons.lang3.StringUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Model class of log lines
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
public class LogItem implements Comparable {

    private static final Logger log = LoggerFactory.getLogger(LogItem.class);

    private long logTimeInMillis;
    private int logType;

    /**
     * Creates a LogItem for the given log line
     * @param s The log line.
     * @param logTimeZone time zone of the dates in log file
     */
    public LogItem(String s, String logTimeZone, DateTimeFormatter formatter) {
        log.debug("A new LogItem is being created from: " + s);
        String date = StringUtils.substring(s, 0, 23);
        log.debug("LogItem date: " + date);
        this.logTimeInMillis =  LocalDateTime.parse(date, formatter).atZone(ZoneId.of(logTimeZone)).toInstant().toEpochMilli();
        log.debug("LogItem date in millis: " + this.logTimeInMillis);
        String sub = StringUtils.substring(s, 24);
        log.debug("LogItem type: " + sub);
        if (sub.startsWith("INFO")) {
            this.logType = 1;
        } else if (sub.startsWith("WARNING")) {
            this.logType = 2;
        } else if (sub.startsWith("ERROR")) {
            this.logType = 3;
        }
        log.debug("LogItem type: " + this.logType);
    }

    /**
     * Creates a abstratc LogItem for the given instant
     * @param instant the time for log item
     */
    public LogItem(Instant instant) {
        this.logTimeInMillis = instant.toEpochMilli();
    }

    /**
     * Returns a log time in millis.
     * @return the log time of LogItem
     */
    public long getLogTimeInMillis() {
        return logTimeInMillis;
    }

    /**
     * Returns a log type 1:INFO 2:WARNING 3:ERROR
     * @return the log type of LogItem
     */
    public int getLogType() {
        return logType;
    }

    /**
     * Compares two LogItem by log time in millis.
     * @return int compare result
     */
    @Override
    public int compareTo(Object o) {
        if(o == null) {
            return 1;
        }
        return Long.compare(this.logTimeInMillis, ((LogItem)o).getLogTimeInMillis());
    }
}

