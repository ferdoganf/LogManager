package firat.logmonitor.controller;

import firat.logmonitor.config.ApplicationProperties;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * MVC Controller
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Controller
public class HomeController {

    @Autowired
    ApplicationProperties applicationProperties;

    @RequestMapping("/")
    public String index(HttpServletRequest request, HttpServletResponse response, @CookieValue(value=ApplicationProperties.COOKIE_NAME_MONITORING_INTERVAL, defaultValue = "") String cookieMonitoringInterval) {
        Cookie cookie = new Cookie(ApplicationProperties.COOKIE_NAME_MONITORING_INTERVAL, this.applicationProperties.getDefaultMonitoringInterval());
        if(StringUtils.isNotEmpty(cookieMonitoringInterval)) {
            cookie.setValue(cookieMonitoringInterval);
        }
        cookie.setMaxAge(86400);
        cookie.setPath("/");
        response.addCookie(cookie);
        return "index.html";
    }
}