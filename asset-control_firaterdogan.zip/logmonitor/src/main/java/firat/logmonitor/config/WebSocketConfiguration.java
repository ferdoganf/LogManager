package firat.logmonitor.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.config.annotation.*;


/**
 * Implementation of WebSocketConfigurer
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Configuration
@EnableWebSocket
public class WebSocketConfiguration implements WebSocketConfigurer {

    @Autowired
    private WebSocketHandler logMonitorWebSocketHandler;

    /**
     * This method used to remove the websocket session
     * @param registry websocket handler registry.
     * @see WebSocketHandler
     */
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(logMonitorWebSocketHandler, ApplicationProperties.WEBSOCKET_CONNECTION_URL);
    }

}