package firat.logmonitor.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;

import java.time.format.DateTimeFormatter;

/**
 * This class for global statics parameters and system parameters in application.properties file
 *
 * @author  Firat Erdogan
 * @version 1.0
 */
@Controller
public class ApplicationProperties {

    public static final String COOKIE_NAME_MONITORING_INTERVAL = "MONITORING_INTERVAL";
    public static final String WEBSOCKET_CONNECTION_URL = "/log-monitor";

    @Value("${logFile:}")
    private String logFile;

    @Value("${defaultMonitoringInterval:2}")
    private String defaultMonitoringInterval;

    @Value("${logItemsInMemoryMaxLimit:1000000}")
    private int logItemsInMemoryMaxLimit;

    @Value("${logFileTailDelayMillis:100}")
    private int logFileTailDelayMillis;

    @Value("${logFileDateTimeZone:UTC}")
    private String logFileDateTimeZone;

    @Value("${logFileDateFormat:yyyy-MM-dd HH:mm:ss,SSS}")
    private String logFileDateFormat;

    private DateTimeFormatter formatter = null;

    /**
     * Default value for the interval of monitoring log
     * @return String default monitoring interval 2, 3, 5 etc. in seconds
     */
    public String getDefaultMonitoringInterval() {
        return defaultMonitoringInterval;
    }

    /**
     * Number of log item can be hold in memory
     * @return integer maximum value of size can be hold in the memory
     */
    public int getLogItemsInMemoryMaxLimit() {
        return logItemsInMemoryMaxLimit;
    }

    /**
     * Log file path
     * @return path of log file
     */
    public String getLogFile() {
        return logFile;
    }

    /**
     * Log file tail delay for new log line
     * @return delay of log file tail
     */
    public int getLogFileTailDelayMillis() {
        return logFileTailDelayMillis;
    }

    /**
     * Log file date time zone
     * @return log file date time zone
     */
    public String getLogFileDateTimeZone() {
        return logFileDateTimeZone;
    }


    public DateTimeFormatter getFormatter() {
        if(this.formatter == null) {
            this.formatter = DateTimeFormatter.ofPattern(logFileDateFormat);
        }
        return formatter;
    }
}
